"""repo-doctor: a health check for Git repositories."""
from .checks import Finding, run_checks, score

__all__ = ["Finding", "run_checks", "score"]
__version__ = "0.1.0"
