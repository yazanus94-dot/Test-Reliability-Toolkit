"""The individual health checks. Each returns a list of :class:`Finding`."""
from __future__ import annotations

import re
import time
from collections import Counter
from dataclasses import dataclass
from typing import Callable, List

from .gitutil import git, has_commits

ERROR, WARNING, INFO = "error", "warning", "info"
PENALTY = {ERROR: 20, WARNING: 10, INFO: 2}

CONVENTIONAL = re.compile(
    r"^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\([^)]+\))?!?: \S.*")


@dataclass(frozen=True)
class Finding:
    check: str
    severity: str
    message: str


def check_community_files(repo: str, **_) -> List[Finding]:
    tracked = git(repo, "ls-files").splitlines()
    names = {t.lower() for t in tracked}
    top = {n.split("/")[0] for n in names}

    def has(prefix: str) -> bool:
        return any(n.startswith(prefix) for n in top)

    findings = []
    if not has("readme"):
        findings.append(Finding("community", ERROR, "No README found"))
    if not has("license") and not has("copying"):
        findings.append(Finding("community", ERROR, "No LICENSE file found"))
    if not has("contributing"):
        findings.append(Finding("community", WARNING, "No CONTRIBUTING guide found"))
    if ".gitignore" not in top:
        findings.append(Finding("community", WARNING, "No .gitignore found"))
    return findings


def check_commit_messages(repo: str, commits: int = 50, min_ratio: float = 0.6, **_) -> List[Finding]:
    if not has_commits(repo):
        return []
    subjects = git(repo, "log", f"-n{commits}", "--no-merges", "--format=%s").splitlines()
    if not subjects:
        return []
    good = sum(1 for s in subjects if CONVENTIONAL.match(s))
    ratio = good / len(subjects)
    if ratio < min_ratio:
        return [Finding("commits", WARNING,
                        f"Only {good}/{len(subjects)} recent commit messages follow Conventional Commits "
                        f"({ratio:.0%}, target {min_ratio:.0%})")]
    return []


def check_large_files(repo: str, max_mb: float = 1.0, **_) -> List[Finding]:
    if not has_commits(repo):
        return []
    objects = git(repo, "rev-list", "--objects", "--all")
    listing = git(repo, "cat-file", "--batch-check=%(objecttype) %(objectsize) %(rest)", input_text=objects)
    limit = int(max_mb * 1024 * 1024)
    big = {}
    for line in listing.splitlines():
        parts = line.split(" ", 2)
        if len(parts) == 3 and parts[0] == "blob" and parts[2] and int(parts[1]) > limit:
            big[parts[2]] = max(big.get(parts[2], 0), int(parts[1]))
    return [Finding("size", WARNING, f"Large file in history: {path} ({size / 1024 / 1024:.1f} MB)")
            for path, size in sorted(big.items(), key=lambda kv: -kv[1])]


def check_stale_branches(repo: str, stale_days: int = 90, **_) -> List[Finding]:
    if not has_commits(repo):
        return []
    current = git(repo, "rev-parse", "--abbrev-ref", "HEAD").strip()
    refs = git(repo, "for-each-ref", "--format=%(refname:short)|%(committerdate:unix)", "refs/heads")
    cutoff = time.time() - stale_days * 86400
    findings = []
    for line in refs.splitlines():
        name, _, stamp = line.rpartition("|")
        if name != current and int(stamp) < cutoff:
            age = int((time.time() - int(stamp)) / 86400)
            findings.append(Finding("branches", INFO, f"Branch '{name}' has had no commits for {age} days"))
    return findings


def check_bus_factor(repo: str, dominance: float = 0.8, **_) -> List[Finding]:
    if not has_commits(repo):
        return []
    authors = Counter(git(repo, "log", "--format=%aN").splitlines())
    total = sum(authors.values())
    top_name, top_count = authors.most_common(1)[0]
    if len(authors) == 1:
        return [Finding("people", INFO, f"Single contributor: {top_name} wrote all {total} commits")]
    share = top_count / total
    if share >= dominance:
        return [Finding("people", WARNING,
                        f"{top_name} wrote {share:.0%} of all commits (bus factor risk)")]
    return []


def check_working_tree(repo: str, **_) -> List[Finding]:
    dirty = git(repo, "status", "--porcelain").splitlines()
    if dirty:
        return [Finding("worktree", INFO, f"{len(dirty)} uncommitted change(s) in the working tree")]
    return []


def check_history(repo: str, **_) -> List[Finding]:
    if not has_commits(repo):
        return [Finding("history", WARNING, "Repository has no commits yet")]
    return []


CHECKS: List[Callable[..., List[Finding]]] = [
    check_history, check_community_files, check_commit_messages, check_large_files,
    check_stale_branches, check_bus_factor, check_working_tree,
]


def run_checks(repo: str, **options) -> List[Finding]:
    findings: List[Finding] = []
    for check in CHECKS:
        findings.extend(check(repo, **options))
    order = {ERROR: 0, WARNING: 1, INFO: 2}
    return sorted(findings, key=lambda f: (order[f.severity], f.check, f.message))


def score(findings: List[Finding]) -> int:
    return max(0, 100 - sum(PENALTY[f.severity] for f in findings))
