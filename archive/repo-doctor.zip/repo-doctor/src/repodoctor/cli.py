"""Command line interface: ``repo-doctor [PATH]``."""
from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .checks import run_checks, score
from .gitutil import GitError, is_repo

ICON = {"error": "ERROR  ", "warning": "WARNING", "info": "INFO   "}


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="repo-doctor", description="Check the health of a Git repository.")
    p.add_argument("path", nargs="?", default=".", help="repository path (default: current directory)")
    p.add_argument("--format", choices=["text", "json", "markdown"], default="text")
    p.add_argument("--fail-under", type=int, default=0, metavar="SCORE",
                   help="exit with code 1 if the health score is below SCORE")
    p.add_argument("--stale-days", type=int, default=90, help="days without commits before a branch is stale")
    p.add_argument("--max-file-mb", type=float, default=1.0, help="flag files larger than this in history")
    p.add_argument("--commits", type=int, default=50, help="how many recent commits to inspect")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if not is_repo(args.path):
            print(f"error: {args.path} is not a Git repository", file=sys.stderr)
            return 2
        findings = run_checks(args.path, stale_days=args.stale_days, max_mb=args.max_file_mb,
                              commits=args.commits)
    except GitError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    total = score(findings)
    if args.format == "json":
        print(json.dumps({"score": total, "findings": [f.__dict__ for f in findings]}, indent=2))
    elif args.format == "markdown":
        print(f"## Repository health: {total}/100\n")
        print("\n".join(f"- **{f.severity}** ({f.check}): {f.message}" for f in findings) or "No issues found.")
    else:
        print(f"Repository health: {total}/100")
        for f in findings:
            print(f"  {ICON[f.severity]} [{f.check}] {f.message}")
        if not findings:
            print("  No issues found.")
    return 1 if total < args.fail_under else 0


if __name__ == "__main__":
    sys.exit(main())
