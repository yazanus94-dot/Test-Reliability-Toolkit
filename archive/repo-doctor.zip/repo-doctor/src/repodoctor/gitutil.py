"""Thin wrapper around the git executable."""
from __future__ import annotations

import subprocess


class GitError(Exception):
    pass


def git(repo: str, *args: str, input_text: str | None = None, check: bool = True) -> str:
    try:
        proc = subprocess.run(["git", "-C", repo, *args], input=input_text, capture_output=True,
                              text=True, encoding="utf-8", errors="replace")
    except FileNotFoundError as exc:
        raise GitError("git executable not found on PATH") from exc
    if check and proc.returncode != 0:
        raise GitError(proc.stderr.strip() or f"git {' '.join(args)} failed")
    return proc.stdout


def is_repo(path: str) -> bool:
    try:
        return git(path, "rev-parse", "--is-inside-work-tree").strip() == "true"
    except GitError:
        return False


def has_commits(repo: str) -> bool:
    return git(repo, "rev-parse", "--verify", "-q", "HEAD", check=False).strip() != ""
