# repo-doctor

[![CI](https://github.com/yazanus94-dot/repo-doctor/actions/workflows/ci.yml/badge.svg)](https://github.com/yazanus94-dot/repo-doctor/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)

A health check for Git repositories. Run it in any repo to get a score out of 100 and a prioritized list of problems.

It inspects the actual Git history, not just the files on disk, so it also finds problems that are invisible in the working tree, like a large binary that was committed once and deleted later but still bloats every clone.

## What it checks

| Check | Looks for | Severity |
|---|---|---|
| community | Missing README or LICENSE | error |
| community | Missing CONTRIBUTING guide or .gitignore | warning |
| commits | Recent commit messages not following [Conventional Commits](https://www.conventionalcommits.org/) | warning |
| size | Large blobs anywhere in history, including deleted files | warning |
| branches | Local branches with no commits for 90+ days | info |
| people | One author wrote 80%+ of commits (bus factor) | warning |
| worktree | Uncommitted changes | info |
| history | Repository without commits | warning |

Score = 100 minus 20 per error, 10 per warning, 2 per info (never below 0).

## Install

```bash
git clone https://github.com/yazanus94-dot/repo-doctor.git
cd repo-doctor
python -m pip install -e .
```

Requires Python 3.9+ and `git` on your PATH. No other dependencies.

## Usage

```bash
repo-doctor                 # check the current directory
repo-doctor ~/code/my-app   # check another repository
```

```text
Repository health: 58/100
  ERROR   [community] No LICENSE file found
  WARNING [commits] Only 12/50 recent commit messages follow Conventional Commits (24%, target 60%)
  WARNING [size] Large file in history: assets/demo.mov (48.2 MB)
  INFO    [branches] Branch 'old-experiment' has had no commits for 214 days
```

### Options

| Option | Description |
|---|---|
| `--format text\|json\|markdown` | Output format |
| `--fail-under SCORE` | Exit with code 1 if the score is below SCORE (for CI gates) |
| `--stale-days N` | Days without commits before a branch is stale (default 90) |
| `--max-file-mb N` | Flag blobs larger than N megabytes (default 1) |
| `--commits N` | How many recent commits to inspect (default 50) |

Exit codes: `0` ok, `1` score below `--fail-under`, `2` not a repository or git error.

### Use it as a CI gate

```yaml
- uses: actions/checkout@v4
  with:
    fetch-depth: 0   # full history is needed for the history checks
- run: python -m pip install repo-doctor
- run: repo-doctor --fail-under 80
```

## How it works

- `git rev-list --objects --all` piped into `git cat-file --batch-check` lists every object in every reachable commit with its size, which is how deleted-but-still-stored files are found.
- `git for-each-ref` reads branch tip dates for the stale-branch check.
- `git log --no-merges` supplies commit subjects and authors.

Each check is a small function returning `Finding` objects, so adding a new one means writing one function and appending it to `CHECKS` in `src/repodoctor/checks.py`.

## Development

Tests create throw-away repositories in temporary directories, including ones with back-dated commits.

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
```

## Roadmap

- Detect committed secrets and `.env` files
- Check for CI configuration and issue templates
- Configuration file for custom thresholds

Contributions are welcome, see [CONTRIBUTING.md](CONTRIBUTING.md).

## License

[MIT](LICENSE) © Yazan Aljabari
