import unittest

from repodoctor.checks import (check_bus_factor, check_commit_messages, check_community_files,
                               check_history, check_large_files, check_stale_branches,
                               check_working_tree, run_checks, score)
from gitfixture import TempRepo


def messages(findings):
    return [f.message for f in findings]


class CommunityTests(unittest.TestCase):
    def test_missing_files_reported(self):
        with TempRepo() as r:
            r.write("main.py")
            r.commit("feat: init")
            msgs = messages(check_community_files(r.path))
        self.assertIn("No README found", msgs)
        self.assertIn("No LICENSE file found", msgs)
        self.assertEqual(len(msgs), 4)

    def test_complete_repo_is_clean(self):
        with TempRepo() as r:
            for name in ("README.md", "LICENSE", "CONTRIBUTING.md", ".gitignore"):
                r.write(name)
            r.commit("docs: add community files")
            self.assertEqual(check_community_files(r.path), [])


class CommitMessageTests(unittest.TestCase):
    def test_non_conventional_commits_flagged(self):
        with TempRepo() as r:
            for i in range(4):
                r.write(f"f{i}.txt", str(i))
                r.commit(f"update stuff {i}")
            findings = check_commit_messages(r.path)
        self.assertEqual(len(findings), 1)
        self.assertIn("0/4", findings[0].message)

    def test_conventional_commits_pass(self):
        with TempRepo() as r:
            for i, msg in enumerate(["feat: a", "fix(core): b", "docs!: c"]):
                r.write(f"f{i}.txt", str(i))
                r.commit(msg)
            self.assertEqual(check_commit_messages(r.path), [])


class LargeFileTests(unittest.TestCase):
    def test_large_blob_found_even_after_deletion(self):
        with TempRepo() as r:
            r.write("data/big.bin", binary_size=300 * 1024)
            r.commit("feat: add data")
            r.git("rm", "-q", "data/big.bin")
            r.commit("chore: remove data")
            findings = check_large_files(r.path, max_mb=0.2)
        self.assertEqual(len(findings), 1)
        self.assertIn("data/big.bin", findings[0].message)

    def test_small_files_ignored(self):
        with TempRepo() as r:
            r.write("small.txt")
            r.commit("feat: small")
            self.assertEqual(check_large_files(r.path, max_mb=1), [])


class StaleBranchTests(unittest.TestCase):
    def test_old_branch_flagged_current_ignored(self):
        old = "2020-01-01T12:00:00"
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("feat: a", date=old)
            r.git("branch", "old-feature")
            r.write("b.txt")
            r.commit("feat: b")
            findings = check_stale_branches(r.path, stale_days=90)
        names = " ".join(messages(findings))
        self.assertIn("old-feature", names)
        self.assertNotIn("'main'", names)


class BusFactorTests(unittest.TestCase):
    def test_single_contributor_is_info(self):
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("feat: a")
            f = check_bus_factor(r.path)
        self.assertEqual(f[0].severity, "info")

    def test_dominant_author_warns(self):
        with TempRepo() as r:
            for i in range(9):
                r.write(f"{i}.txt", str(i))
                r.commit(f"feat: {i}", author="Alice")
            r.write("z.txt")
            r.commit("feat: z", author="Bob")
            f = check_bus_factor(r.path)
        self.assertEqual(f[0].severity, "warning")
        self.assertIn("Alice", f[0].message)

    def test_balanced_team_is_fine(self):
        with TempRepo() as r:
            for i in range(4):
                r.write(f"{i}.txt", str(i))
                r.commit(f"feat: {i}", author="Alice" if i % 2 else "Bob")
            self.assertEqual(check_bus_factor(r.path), [])


class MiscTests(unittest.TestCase):
    def test_empty_repo(self):
        with TempRepo() as r:
            self.assertEqual(messages(check_history(r.path)), ["Repository has no commits yet"])
            self.assertEqual(check_large_files(r.path), [])
            findings = run_checks(r.path)
        self.assertTrue(any("no commits" in f.message for f in findings))

    def test_dirty_working_tree(self):
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("feat: a")
            r.write("a.txt", "changed")
            self.assertEqual(len(check_working_tree(r.path)), 1)

    def test_score_penalties_and_floor(self):
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("update")
            findings = run_checks(r.path)
        self.assertLess(score(findings), 100)
        self.assertEqual(score([]), 100)
        self.assertGreaterEqual(score(findings * 20), 0)


if __name__ == "__main__":
    unittest.main()
