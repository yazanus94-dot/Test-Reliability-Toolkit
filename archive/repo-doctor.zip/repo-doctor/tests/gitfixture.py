"""Helpers that build throw-away Git repositories for tests."""
import os
import subprocess
import tempfile

ENV = {**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "t@example.com",
       "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "t@example.com",
       "GIT_CONFIG_GLOBAL": os.devnull, "GIT_CONFIG_SYSTEM": os.devnull}


def run(repo, *args, env=None):
    subprocess.run(["git", "-C", repo, *args], check=True, capture_output=True, text=True,
                   env={**ENV, **(env or {})})


class TempRepo:
    def __enter__(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.path = self._tmp.name
        run(self.path, "init", "-q", "-b", "main")
        return self

    def __exit__(self, *exc):
        self._tmp.cleanup()

    def write(self, name, content="x", binary_size=None):
        full = os.path.join(self.path, name)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        if binary_size:
            with open(full, "wb") as fh:
                fh.write(os.urandom(binary_size))
        else:
            with open(full, "w") as fh:
                fh.write(content)

    def commit(self, message, author=None, date=None):
        run(self.path, "add", "-A")
        env = {}
        if author:
            env.update(GIT_AUTHOR_NAME=author, GIT_COMMITTER_NAME=author)
        if date:
            env.update(GIT_AUTHOR_DATE=date, GIT_COMMITTER_DATE=date)
        run(self.path, "commit", "-q", "-m", message, env=env)

    def git(self, *args):
        run(self.path, *args)
