import contextlib
import io
import json
import tempfile
import unittest

from repodoctor.cli import main
from gitfixture import TempRepo


def invoke(*argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = main(list(argv))
    return code, out.getvalue(), err.getvalue()


class CliTests(unittest.TestCase):
    def test_not_a_repo(self):
        with tempfile.TemporaryDirectory() as d:
            code, _, err = invoke(d)
        self.assertEqual(code, 2)
        self.assertIn("not a Git repository", err)

    def test_text_and_json_output(self):
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("feat: a")
            code, out, _ = invoke(r.path)
            self.assertEqual(code, 0)
            self.assertIn("Repository health:", out)
            code, out, _ = invoke(r.path, "--format", "json")
        data = json.loads(out)
        self.assertIn("score", data)
        self.assertTrue(any(f["check"] == "community" for f in data["findings"]))

    def test_markdown_output(self):
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("feat: a")
            _, out, _ = invoke(r.path, "--format", "markdown")
        self.assertTrue(out.startswith("## Repository health"))

    def test_fail_under(self):
        with TempRepo() as r:
            r.write("a.txt")
            r.commit("update")
            code, _, _ = invoke(r.path, "--fail-under", "95")
        self.assertEqual(code, 1)


if __name__ == "__main__":
    unittest.main()
